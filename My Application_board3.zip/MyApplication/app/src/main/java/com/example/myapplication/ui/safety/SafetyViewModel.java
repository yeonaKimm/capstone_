package com.example.myapplication.ui.safety;

import androidx.lifecycle.ViewModel;

public class SafetyViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}