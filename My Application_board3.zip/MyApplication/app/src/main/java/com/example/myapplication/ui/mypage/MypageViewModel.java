package com.example.myapplication.ui.mypage;

import androidx.lifecycle.ViewModel;

public class MypageViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}