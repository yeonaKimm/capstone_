package com.example.myapplication.ui.chat;

import androidx.lifecycle.ViewModel;

public class ChatViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}