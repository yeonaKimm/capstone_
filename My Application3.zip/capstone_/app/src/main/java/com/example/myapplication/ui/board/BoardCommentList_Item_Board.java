package com.example.myapplication.ui.board;

public class BoardCommentList_Item_Board {
    private String content;

    public BoardCommentList_Item_Board(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
